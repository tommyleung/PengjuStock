﻿SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS  `stock_quote`;
CREATE TABLE `stock_quote` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `stock_code` varchar(45) NOT NULL COMMENT '股票代码',
  `stock_capital` decimal(10,0) NOT NULL COMMENT '总股本',
  `stock_floating` decimal(10,0) NOT NULL COMMENT '流通股本',
  `stock_pe` double NOT NULL COMMENT '市盈率',
  `stock_pb` double NOT NULL COMMENT '市净率',
  `stock_ps` double NOT NULL COMMENT '市销率',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `stock_market_capital` decimal(10,0) NOT NULL COMMENT '总市值',
  `stock_dividend` double DEFAULT NULL COMMENT '每股股息，年度为单位',
  `stock_net_assert` double NOT NULL COMMENT '每股净资产',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='股票当前概要信息表，每季度采集一次';

DROP TABLE IF EXISTS  `stock_financial_index`;
CREATE TABLE `stock_financial_index` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `stock_code` varchar(45) NOT NULL COMMENT '股票代码',
  `index_id` varchar(45) NOT NULL COMMENT '指标代码',
  `index_value` double DEFAULT NULL COMMENT '指标值',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `index_name` varchar(100) DEFAULT NULL COMMENT '指标名称',
  `index_season` varchar(45) DEFAULT NULL COMMENT '股票季度',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27485 DEFAULT CHARSET=utf8 COMMENT='股票财务指标按季度（一季度、半年度、三季报、年度）';

DROP TABLE IF EXISTS  `stock_index_d`;
CREATE TABLE `stock_index_d` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '指标ID',
  `index_name` varchar(100) NOT NULL COMMENT '指标名称',
  `index_unit` varchar(45) NOT NULL COMMENT '指标单位',
  `index_descriptor` varchar(2000) DEFAULT ' ' COMMENT '指标描述',
  `update_date` datetime NOT NULL COMMENT '更新时间',
  `parent_id` bigint(20) DEFAULT NULL COMMENT '父指标ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='财务指标描述';

DROP TABLE IF EXISTS  `stock_price_day`;
CREATE TABLE `stock_price_day` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `stock_code` varchar(45) NOT NULL COMMENT '股票代码',
  `stock_price_open` double NOT NULL COMMENT '开盘价',
  `stock_price_close` double NOT NULL COMMENT '收盘价',
  `stock_price_high` double NOT NULL COMMENT '最高价',
  `stock_price_low` double NOT NULL COMMENT '最低价',
  `stock_volume` bigint(20) NOT NULL COMMENT '成交量',
  `stock_turn` decimal(10,0) NOT NULL COMMENT '成交额',
  `create_date_open` datetime NOT NULL COMMENT '开盘时间',
  `create_date_close` datetime NOT NULL COMMENT '关闭时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='股票日线数据，每日采集';

DROP TABLE IF EXISTS  `stock_info`;
CREATE TABLE `stock_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_code` varchar(45) NOT NULL COMMENT '股票代码',
  `stock_name` varchar(45) NOT NULL COMMENT '股票名称',
  `stock_marketing` varchar(45) DEFAULT NULL COMMENT '市场类型',
  `stock_industry` varchar(45) DEFAULT NULL COMMENT '所属行业',
  `is_valid` int(11) NOT NULL DEFAULT '0',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `stock_type` varchar(45) DEFAULT NULL COMMENT '股票类型，SZ深证主板, SH上海主板',
  `company_intro` varchar(2000) DEFAULT NULL COMMENT '公司简介',
  `company_addr` varchar(1000) DEFAULT NULL COMMENT '公司地址',
  `major_business` varchar(1000) DEFAULT NULL COMMENT '主营业务',
  `company_name` varchar(100) DEFAULT NULL COMMENT '公司名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='所关注的股票信息表';

SET FOREIGN_KEY_CHECKS = 1;

