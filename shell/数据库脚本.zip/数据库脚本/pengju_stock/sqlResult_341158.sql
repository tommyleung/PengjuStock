﻿insert into `stock_info`(`id`,`stock_code`,`stock_name`,`stock_marketing`,`stock_industry`,`is_valid`,`update_time`,`create_time`,`stock_type`,`company_intro`,`company_addr`,`major_business`,`company_name`) values
('2','002839','张家港行','深圳主板','银行','0','2017-08-13 18:13:30','2017-08-13 18:13:30','SZ',null,null,null,null),
('1','002516','徐家汇','深圳主板','零售','0','2017-08-13 18:13:30','2017-08-13 18:13:30','SZ',null,null,null,null);
