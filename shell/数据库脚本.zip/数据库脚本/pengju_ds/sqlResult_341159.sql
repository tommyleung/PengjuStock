﻿insert into `repaire_system_param`(`id`,`param_name`,`param_description`,`param_value`,`remark`,`param_icon`,`param_title`,`is_show`,`param_style`,`param_type`) values
('15','factTime','承诺时效','48','','glyphicon glyphicon-calendar','承诺时效','1','#12B5E7','1'),
('9','clientSatisfy','客户满意度','100','','glyphicon glyphicon-thumbs-up','客户满意度','1','#D0DCDE','2'),
('8','clientCount','客户数目','300','','glyphicon glyphicon-user','客户数目','1','#16D2E0','2'),
('7','userSatisfy','用户满意度','100','','glyphicon glyphicon-thumbs-up','用户满意度','1','#ff0000','1'),
('6','landConUserCount','地暖户用户数目','150','','glyphicon glyphicon-random','地暖用户','1','#3bd4c0','1'),
('5','airConUserCount','空调用户数目','150','','glyphicon glyphicon-cloud','空调用户','1','#7DB7FE','1'),
('4','villageCount','服务过的小区数目','30','','glyphicon glyphicon-globe','小区数目','1','#43DE14','1'),
('3','employeCount','员工数目','20','','glyphicon glyphicon-user','团队规模','1','#8dc12b','1'),
('2','caseCount','公司案例数目','200','','glyphicon glyphicon-globe','案例数目','0','#ff0000','1'),
('1','userCount','用户数目','100','','glyphicon glyphicon-globe','用户数目','0','#ff0000','1');
