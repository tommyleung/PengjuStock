﻿SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS  `repaire_system_visit`;
CREATE TABLE `repaire_system_visit` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ipAdress` varchar(32) DEFAULT NULL COMMENT '访问的IP地址',
  `visit_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '访问时间',
  `url` varchar(2000) DEFAULT NULL COMMENT '访问url',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统访问日志';

DROP TABLE IF EXISTS  `repaire_case_detail`;
CREATE TABLE `repaire_case_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` int(11) NOT NULL COMMENT '关联case id',
  `detail_content` varchar(4000) NOT NULL COMMENT '案例图片',
  `detail_url` varchar(1000) NOT NULL COMMENT '案例详情图片地址',
  `detail_sort` int(11) NOT NULL COMMENT '排序',
  `is_valid` int(11) NOT NULL DEFAULT '0' COMMENT '是否有效',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `repaire_user`;
CREATE TABLE `repaire_user` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(200) NOT NULL COMMENT '用户名',
  `user_password` varchar(200) NOT NULL COMMENT '密码',
  `user_comment` varchar(1000) DEFAULT NULL COMMENT '备注',
  `user_email` varchar(45) DEFAULT NULL COMMENT '电子邮箱',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='芃居维保用户表';

DROP TABLE IF EXISTS  `repaire_system_param`;
CREATE TABLE `repaire_system_param` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param_name` varchar(45) NOT NULL COMMENT '参数名称',
  `param_description` varchar(45) NOT NULL COMMENT '参数描述',
  `param_value` varchar(1000) NOT NULL COMMENT '参数值',
  `remark` varchar(1000) DEFAULT NULL,
  `param_icon` varchar(50) DEFAULT NULL,
  `param_title` varchar(100) NOT NULL DEFAULT '' COMMENT 'title',
  `is_show` varchar(2) NOT NULL DEFAULT '1' COMMENT '是否显示',
  `param_style` varchar(200) DEFAULT '',
  `param_type` varchar(2) NOT NULL DEFAULT '1' COMMENT '类型',
  PRIMARY KEY (`id`),
  UNIQUE KEY `param_name_UNIQUE` (`param_name`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `repaire_case`;
CREATE TABLE `repaire_case` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_title` varchar(200) NOT NULL COMMENT '案例主题',
  `case_content` varchar(4000) NOT NULL COMMENT '相关内容',
  `user_id` int(11) DEFAULT NULL COMMENT '相关用户ID',
  `case_type` varchar(100) DEFAULT NULL COMMENT '案例类型',
  `case_address` varchar(200) NOT NULL COMMENT '案例地址',
  `case_urls` varchar(2000) NOT NULL DEFAULT '' COMMENT '案例图片(最多10张，使用逗号隔开)',
  `case_remark` varchar(1000) DEFAULT '',
  `case_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '案例时间',
  `is_valid` int(11) NOT NULL DEFAULT '0' COMMENT '是否有效',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 COMMENT='维修案例';

DROP TABLE IF EXISTS  `repaire_message`;
CREATE TABLE `repaire_message` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `message_user_name` varchar(45) NOT NULL COMMENT '信息留言姓名',
  `message_phone` varchar(45) NOT NULL COMMENT '电话号码',
  `message_content` varchar(2000) DEFAULT NULL COMMENT '留言信息',
  `message_email` varchar(45) DEFAULT NULL COMMENT '邮箱',
  `message_address` varchar(45) DEFAULT NULL COMMENT '用户地址',
  `message_type` varchar(45) NOT NULL COMMENT '消息类型, 维修类型',
  `message_time` datetime DEFAULT NULL,
  `message_do_time` datetime DEFAULT NULL,
  `is_valid` int(11) NOT NULL DEFAULT '0',
  `message_status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8 COMMENT='芃居维保客户留言信息';

SET FOREIGN_KEY_CHECKS = 1;

